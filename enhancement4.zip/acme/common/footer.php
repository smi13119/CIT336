
<!--
Footer
-->

        <p id="copyright"> Copyright &copy; Acme, All Rights reserved. All images used are believed to be in <q>Fair Use</q>. Please notify the author if they are not and they will be removed.</p> 
        
        <p>Click the button to display the date and time this document was last modified.</p>
        <button onclick="myFunction()">Try it</button>
        <p id="demo"></p>
        <script>
            function myFunction() {
                var x = document.lastModified;document.getElementById("demo").innerHTML =x;
            }
            </script>
            
            
        
        <?php
        // put your code here
        ?>


   
