
<!--
Navigation
-->

        <div class="navdiv">
            <ul class="navtabs">
                <li>Home</li>
                <li>Anvils</li>
                <li>Cannons</li>
                <li>Protection</li>
                <li>Rockets</li>
                <li>Traps</li>
            </ul>
        </div>
       
