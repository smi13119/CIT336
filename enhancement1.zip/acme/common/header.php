
<!--
Header
-->



        
      <figure class="header-left">
        <img class="img50p"  src='/acme/images/site/logo.gif' alt='Logo'/>
        
    </figure>
    
    <figure class="header-right">
        <img class="img50p" src='/acme/images/site/account.gif' alt='account'/>
        <figcaption class="inlinecaption"> My Account </figcaption>
    </figure> 

    

   